package com.example.ordersystem

import androidx.compose.runtime.Composable
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.ui.tooling.preview.Preview
import com.example.ordersystem.models.Food

@Composable
public fun OrderPage(
    datas: List<Food>
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
    ) {
        items(datas.size) {
            FoodCard(datas.get(it))
        }
    }
}

@Preview
@Composable
fun OrderPagePreview() {
    val d1 = Food(
        name = "羊肉串",
        img = R.drawable.yrc,
        price = 10,
        quantity = 2,
        unit = "串",
    )
    val d2 = Food(
        name = "烤鸡翅",
        img = R.drawable.jc,
        price = 10,
        quantity = 0,
        unit = "串",
    )
    
    val d3 = Food(
        name = "烤面筋",
        img = R.drawable.mj,
        price = 10,
        quantity = 2,
        unit = "串",
    )
    
    val d4 = Food(
        name = "烤土豆片",
        img = R.drawable.tdp ,
        price = 10,
        quantity = 5,
        unit = "串",
    )
    
    val datas = listOf(
        d1, d2, d3, d4,
    )
    
    OrderPage(datas)
}