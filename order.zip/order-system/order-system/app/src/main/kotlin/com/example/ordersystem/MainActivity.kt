package com.example.ordersystem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.ordersystem.models.Food
import com.example.ordersystem.OrderPage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val d1 = Food(
                name = "羊肉串",
                img = R.drawable.yrc,
                price = 10,
                quantity = 2,
                unit = "串",
            )
            val d2 = Food(
                name = "烤鸡翅",
                img = R.drawable.jc,
                price = 10,
                quantity = 0,
                unit = "串",
            )

            val d3 = Food(
                name = "烤面筋",
                img = R.drawable.mj,
                price = 10,
                quantity = 2,
                unit = "串",
            )

            val d4 = Food(
                name = "烤土豆片",
                img = R.drawable.tdp,
                price = 10,
                quantity = 5,
                unit = "串",
            )

            val datas = listOf(
                d1, d2, d3, d4,
            )
            
            OrderPage(datas)
        }
    }
}
