package com.example.ordersystem.models

data class Food(
    val name: String,
    val img: Int,
    val price: Int,
    val quantity: Int,
    val unit: String,
)
