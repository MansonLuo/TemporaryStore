package com.example.ordersystem

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Row
import com.example.ordersystem.models.Food
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add

@Composable
public fun FoodCard(food: Food) {
    Card(
        modifier = Modifier.width(100.dp),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
    ) {
        Box(
            modifier = Modifier
        ) {
            Image(painterResource(food.img), "")

            // 2. 顶部渐变（防止徽章看不清）
            Box(
                modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.Transparent,
                        )
                    )
                )
                .align(Alignment.TopCenter),
            )

            // 3. 红色徽章（左上角）
            if (food.quantity > 0) {
                Box(
                    modifier = Modifier
                    .padding(8.dp)
                    .size(28.dp)
                    .background(
                        color = Color(0xFFE53935),
                        shape = CircleShape,
                    )
                    .border(2.dp, Color.White, shape = CircleShape)
                    .align(Alignment.TopStart),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = if (food.quantity > 99) "99+" else food.quantity.toString(),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Box(
                modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.75f),
                        )
                    )
                )
                .align(Alignment.BottomCenter)
            )

            Column(
                modifier = Modifier
                .align(Alignment.BottomCenter,
                )
                .padding(start = 12.dp, end = 12.dp, bottom = 1.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = "${food.name}",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                )

                Row(
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Text(
                        text = "${food.price.toString()} / ",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = food.unit,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 2.dp, bottom = 1.dp)
                    )
                }
                
                Row(
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        ""
                        
                    )
                }
            }

        }
    }
}

@Preview(showBackground = true)
@Composable
fun FoodCardPreview() {
    val food = Food(
        quantity = 10,
        img = R.drawable.jc,
        name = "鸡翅",
        price = 10,
        unit = "串",
    )
    FoodCard(food)
}
